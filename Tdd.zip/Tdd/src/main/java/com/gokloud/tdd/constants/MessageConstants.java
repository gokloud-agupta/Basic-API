package com.gokloud.tdd.constants;

public class MessageConstants {

	public static final String HIPHEN = "-";

	public static final String COMMA = ",";

	public static final int J = 1;

	protected MessageConstants() {
	}
}
