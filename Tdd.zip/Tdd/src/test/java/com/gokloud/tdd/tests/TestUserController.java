package com.gokloud.tdd.tests;

import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.gokloud.tdd.controller.UserController;

@RunWith(MockitoJUnitRunner.class)
public class TestUserController {

	@InjectMocks
	UserController userController;

//	@Mock
//	EmployeeDao dao;
}
